// import {StyleSheet} from 'react-native';


// const AppStyles = StyleSheet.create({
//  component1: {
//    color: "white",
//  },
// });

// export AppStyles;
